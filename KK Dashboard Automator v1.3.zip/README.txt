///////////////////////////ENG_README///////////////////////////

Python must be installed. (https://www.python.org)
!!! DONT FORGET to check "Add Python 3.xx to PATH" when you install python.
You must install the **required libraries** on the first run.  
Chrome must be up to date.  

========================================  

1. Get the pid  

# Go to the Kackiest Kacky website and search for your nickname (or find it manually)  
https://kackiestkacky.com/  

# Open your user profile and copy the corresponding pid  
https://kackiestkacky.com/hunting/editions/players.php?pid=OOOO&edition=0  
OOOO is your pid.  

# Enter the pid in the program.  

========================================  

2. Get the SHEET_ID  

# Open the Kackiest Kacky Dashboard Google Sheet link  
https://docs.google.com/spreadsheets/d/1G44h9PAHVSKkYwD4ek_v6WpI696QPMAJPo1dMVi1IdM/edit?gid=92899346#gid=92899346  

# Make a copy of the Google Sheet.  
File - Make a copy  

# Click the Share button and change access permissions to **Anyone with the link**.  
Then change the role to **Editor**.  

# Copy the part of the URL corresponding to the SHEET ID  
https://docs.google.com/spreadsheets/d/{SHEET_ID}/edit?usp=sharing  

# Enter the SHEET ID in the program.  

========================================  

3. Click the script execution button.  

# On the first run, click the **Install Required Libraries** button.  



///////////////////////////KOR_README///////////////////////////

Python이 설치되어 있어야 합니다. (https://www.python.org)
!!! Python을 설치할 때 "Python 3.xx를 PATH에 추가"를 체크하는 것을 잊지 마세요.
첫 실행 시 꼭 **필수 라이브러리**를 설치해야 합니다.
Chrome이 최신 버전이어야 합니다.

========================================

1. pid 가져오기

# 카키 홈페이지에 접속하여 본인의 닉네임을 검색 (또는 직접 찾기)
https://kackiestkacky.com/

# 유저 프로필에 들어가 해당되는 pid 복사하기
https://kackiestkacky.com/hunting/editions/players.php?pid=OOOO&edition=0
OOOO가 pid입니다.

# 프로그램에 pid를 입력하세요.

========================================

2. SHEET_ID 가져오기

# Kackiest Kacky Dashboard 구글 시트 링크에 접속
https://docs.google.com/spreadsheets/d/1G44h9PAHVSKkYwD4ek_v6WpI696QPMAJPo1dMVi1IdM/edit?gid=92899346#gid=92899346

# 구글 시트의 사본을 만드세요.
파일 - 사본 만들기

# 공유 버튼을 눌러 엑세스 권한을 **링크가 있는 모든 사용자**로 변경하세요.
그리고 역할을 **편집자**로 변경하세요.

# 주소 창에 SHEET ID에 해당하는 부분을 복사하세요
https://docs.google.com/spreadsheets/d/{SHEET_ID}/edit?usp=sharing

# 프로그램에 SHEET ID를 입력하세요

========================================

3. 스크립트 실행 버튼을 누르세요.

# 첫 실행 시 필수 라이브러리 설치 버튼을 누르세요.